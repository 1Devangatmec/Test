import React, { useState } from "react";
import { View, Text, TextInput, Button, FlatList, StyleSheet } from "react-native";

type Item = {
  id: string;
  name: string;
  stock: number;
  sold: number;
  partySales: { party: string; qty: number }[];
};

export default function HomeScreen() {
  const [items, setItems] = useState<Item[]>([
    { id: "1", name: "Item A", stock: 1000, sold: 0, partySales: [] },
    { id: "2", name: "Item B", stock: 500, sold: 0, partySales: [] },
    { id: "3", name: "Item C", stock: 200, sold: 0, partySales: [] },
  ]);

  const [selectedItem, setSelectedItem] = useState<string>("");
  const [party, setParty] = useState<string>("");
  const [qty, setQty] = useState<string>("");

  const addSale = () => {
    if (!selectedItem || !party || !qty) return;

    setItems((prev) =>
      prev.map((item) =>
        item.id === selectedItem
          ? {
              ...item,
              sold: item.sold + Number(qty),
              partySales: [...item.partySales, { party, qty: Number(qty) }],
            }
          : item
      )
    );

    setParty("");
    setQty("");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>📦 Inventory Manager</Text>

      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.itemName}>{item.name}</Text>
            <Text>Stock: {item.stock}</Text>
            <Text>Sold: {item.sold}</Text>
            <Text>Remaining: {item.stock - item.sold}</Text>
          </View>
        )}
      />

      <Text style={styles.subHeader}>➕ Add Sale</Text>

      <TextInput
        style={styles.input}
        placeholder="Item ID (1, 2, 3)"
        value={selectedItem}
        onChangeText={setSelectedItem}
        keyboardType="numeric"
      />

      <TextInput
        style={styles.input}
        placeholder="Party Name"
        value={party}
        onChangeText={setParty}
      />

      <TextInput
        style={styles.input}
        placeholder="Quantity Sold"
        value={qty}
        onChangeText={setQty}
        keyboardType="numeric"
      />

      <Button title="Add Sale" onPress={addSale} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#f5f5f5" },
  header: { fontSize: 22, fontWeight: "bold", marginBottom: 15, textAlign: "center" },
  subHeader: { fontSize: 18, fontWeight: "bold", marginVertical: 10 },
  card: {
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 10,
    marginVertical: 5,
    elevation: 2,
  },
  itemName: { fontSize: 18, fontWeight: "bold" },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    padding: 10,
    marginVertical: 5,
    backgroundColor: "#fff",
  },
});
